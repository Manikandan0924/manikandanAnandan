$(document).ready(function () {

    $('#searchType').val('personnel');


// Function to generate search table for personnel
function generatePersonnelSearchTable(data) {
    let tableHtml = '';
    // Check if data is not empty and if 'found' property exists
    if (data && data.found) {

        let key = 1;
        // Add table rows with data and edit/delete buttons
        data.found.forEach(entry => {
            tableHtml += '<tr>';
            tableHtml += `<td>${key++}</td>`;
            tableHtml += `<td>${entry.firstName}</td>`;
            tableHtml += `<td>${entry.lastName}</td>`;
            tableHtml += `<td>${entry.email}</td>`;
            tableHtml += `<td>${entry.departmentName}</td>`; // Use departmentName instead of department
            tableHtml += `<td>${entry.locationName}</td>`; // Use locationName instead of location
            // tableHtml += `<td>${entry.departmentID}</td>`; // Display departmentID
            // tableHtml += `<td>${entry.locationID}</td>`; // Display locationID
            tableHtml += '<td>';
            // Edit button
            tableHtml += `<button class="btn btn-primary btn-sm edit-btn Personnel-edit-btn" 
            data-email="${entry.email}" data-departmentID="${entry.departmentID}" data-firstName="${entry.firstName}" data-lastName="${entry.lastName}" data-jobTitle="${entry.jobTitle}"
            data-id="${entry.id}"><i class="fa-solid fa-pencil fa-fw"></i></button>`;
            // Add some space between the buttons
            tableHtml += '&nbsp;';
            // Delete button
            tableHtml += `<button class="btn btn-danger btn-sm delete-btn Personnel-delete-btn" data-name="${entry.firstName} ${entry.lastName}" data-id="${entry.id}"><i class="fa-solid fa-trash fa-fw"></i></button>`;
            tableHtml += '</td>';
            tableHtml += '</tr>';
        });
    } else {
        // If no data is found, display a message
        tableHtml += '<tr><td colspan="6">No results found.</td></tr>';
    }

    // Update the personnel table body with the generated HTML
    $('#personnelTableBody').html(tableHtml);
}

// Function to generate search table for departments
function generateDepartmentSearchTable(data) {
    let tableHtml = '';
    let key = 1; // Initialize a variable to keep track of the incrementing value
    // Check if data is not empty and if 'found' property exists
    if (data && data.found) {
        // Add table rows with department details
        data.found.forEach(department => {
            tableHtml += '<tr>';
            tableHtml += `<td>${key++}</td>`;
            tableHtml += `<td>${department.name}</td>`;
            tableHtml += `<td>${department.locationName}</td>`; // Display department location
            tableHtml += '<td>';
             // Edit button
             tableHtml += `<button class="btn btn-primary btn-sm Department-edit-btn" data-id="${department.id}"><i class="fa-solid fa-pencil fa-fw"></i></button>`;
             // Add some space between the buttons
            tableHtml += '&nbsp;';
             // Delete button
             tableHtml += `<button class="btn btn-danger btn-sm Department-delete-btn" data-id="${department.id}"><i class="fa-solid fa-trash fa-fw"></i></button>`;
             tableHtml += '</td>';
             tableHtml += '</tr>';
        });
    } else {
        // If no data is found, display a message
        tableHtml += '<tr><td colspan="6">No results found.</td></tr>';
    }

    // Update the department table body with the generated HTML
    $('#departmentTableBody').html(tableHtml);
}

// Function to generate search table for locations
function generateLocationSearchTable(data) {
    let tableHtml = '';
    let key = 1; // Initialize a variable to keep track of the incrementing value
    // Check if data is not empty and if 'found' property exists
    if (data && data.found) {
        // Add table rows with data and edit/delete buttons
        data.found.forEach(location => {
            tableHtml += '<tr>';
            tableHtml += `<td>${key++}</td>`; // Use locationid instead of id
            tableHtml += `<td>${location.locationname}</td>`; // Use locationname instead of locationName
            tableHtml += '<td>';
           // Edit button
           tableHtml += `<button class="btn btn-primary btn-sm edit-btn Location-edit-btn" data-id="${location.locationid}"><i class="fa-solid fa-pencil fa-fw"></i></button>`;
           // Add some space between the buttons
           tableHtml += '&nbsp;';
           // Delete button
           tableHtml += `<button class="btn btn-danger btn-sm delete-btn Location-delete-btn" data-id="${location.locationid}"><i class="fa-solid fa-trash fa-fw"></i></button>`;
           tableHtml += '</td>';
           tableHtml += '</tr>';
        });
    } else {
        // If no data is found, display a message
        tableHtml += '<tr><td colspan="6">No results found.</td></tr>';
    }

    // Update the location table body with the generated HTML
    $('#locationTableBody').html(tableHtml);
}


// Function to fetch and generate search table
function fetchAndGenerateSearchTable(searchText, searchType) {

    // if(searchText != ''){

        $.ajax({
            url: "php/searchAll.php",
            type: "GET",
            dataType: "json",
            data: {
                txt: searchText,
                type: searchType // Add search type parameter
            },
            success: function (response) {
                // Handle the response data here
                // // // console.log(response);
                // Update the table with the search results
                switch (searchType) {
                    case 'personnel':
                        generatePersonnelSearchTable(response.data);
                        break;
                    case 'department':
                        generateDepartmentSearchTable(response.data);
                        break;
                    case 'location':
                        generateLocationSearchTable(response.data);
                        break;
                    default:
                        // // // console.error('Invalid search type:', searchType);
                }
            },
            error: function (xhr, status, error) {
                // Handle errors here
                // // console.error(error);
            }
        });
    // }

}

// Search functionality
$("#searchInp").on("keyup", function () {
    var searchText = $(this).val().trim();
    var searchType = $('#searchType').val(); // Get the selected search type
    // Fetch and generate table using searchAll.php
    fetchAndGenerateSearchTable(searchText, searchType);
});

// Function to refresh the table based on selected search type
function refreshTableBasedOnSearchType() {
    var searchText = $("#searchInp").val().trim();
    var searchType = $('#searchType').val(); // Get the selected search type
    fetchAndGenerateSearchTable(searchText, searchType);
}

// Search type change event
$('#searchType').change(function () {
    refreshTableBasedOnSearchType();
});

// Initial table generation
refreshTableBasedOnSearchType();





    // Function to generate table
    function generatePersonnelTable(data, tableBodyId) {
        // Sort data by ID in ascending order
        data.sort((a, b) => a.id - b.id);
        let key = 1; // Initialize a variable to keep track of the incrementing value

        let tableHtml = '';
        // Add table rows with data and edit/delete buttons
        data.forEach(entry => {
            tableHtml += '<tr>';
            tableHtml += `<td>${key++}</td>`;
            tableHtml += `<td>${entry.firstName}</td>`;
            tableHtml += `<td>${entry.lastName}</td>`;
            tableHtml += `<td>${entry.email}</td>`;
            tableHtml += `<td>${entry.department}</td>`; // Use department instead of departmentName
            tableHtml += `<td>${entry.location}</td>`; // Use location instead of locationName
            tableHtml += '<td>';
            // Edit button
            tableHtml += `<button class="btn btn-primary btn-sm Personnel-edit-btn"
            data-email="${entry.email}" data-departmentID="${entry.department}" data-firstName="${entry.firstName}" data-lastName="${entry.lastName}"
             data-id="${entry.id}"><i class="fa-solid fa-pencil fa-fw"></i></button>`;
            // Add some space between the buttons
            tableHtml += '&nbsp;';
            // Delete button
            tableHtml += `<button class="btn btn-danger btn-sm Personnel-delete-btn" data-name="${entry.firstName} ${entry.lastName}"  data-id="${entry.id}"><i class="fa-solid fa-trash fa-fw"></i></button>`;
            tableHtml += '</td>';
            tableHtml += '</tr>';
        });

        // Update the table body with the generated HTML
        $('#' + tableBodyId).html(tableHtml);
    }







    
    // Function to fetch and generate table
    function fetchAndGenerateTable(searchText, tableBodyId) {
        $.ajax({
            url: "php/getAll.php", // Corrected filename
            type: "GET",
            dataType: "json",
            data: {
                txt: searchText
            },
            success: function (response) {
                // Handle the response data here
                // // console.log(response);
                generatePersonnelTable(response.data, tableBodyId);
            },
            error: function (xhr, status, error) {
                // Handle errors here
                // // // console.error(error);
            }
        });
    }

    // Initial table generation
    fetchAndGenerateTable(null, 'personnelTableBody');


   // Event listener when the add personnel modal is shown
$('#addpersonnelModal').on('shown.bs.modal', function (e) {
    // Populate the department dropdown when the modal is shown
    populatePersonnelDepartmentDropdown();
});

// Function to populate the department dropdown in the add personnel modal
function populatePersonnelDepartmentDropdown() {
    $.ajax({
        url: "php/getDepartmentDetails.php",
        type: "GET",
        dataType: "json",
        success: function(response) {
            // Clear existing dropdown options
            $('#addPersonnelDepartment').empty();
            // Populate dropdown with fetched departments
            $.each(response.data, function(index, department) {
                $('#addPersonnelDepartment').append($('<option>', {
                    value: department.id,
                    text: department.name
                }));
            });
        },
        error: function(xhr, status, error) {
            // // console.error("Error fetching departments:", error);
            // Handle error if needed
        }
    });
}




   // Function to handle the submission of the "Add Personnel" form
$("#addPersonnelForm").click(function () {
    // Get the personnel details from the input fields
    var addPersonnelFirstName = $("#addPersonnelFirstName").val();
    var addPersonnelLastName = $("#addPersonnelLastName").val();
    var addPersonnelEmailAddress = $("#addPersonnelEmailAddress").val();
    var addPersonnelDepartment = $("#addPersonnelDepartment").val();

    // AJAX request to send data to the server
    $.ajax({
        url: "php/createPersonnel.php",
        type: "POST",
        dataType: "json",
        data: {
            firstName: addPersonnelFirstName,
            lastName: addPersonnelLastName,
            email: addPersonnelEmailAddress,
            departmentID: addPersonnelDepartment
        },
        success: function (response) {
            // // console.log(response);
            // Check if the server successfully processed the request
            if (response.status.code === "200") {
                // Close the modal after successful addition of personnel
                $("#addpersonnelModal").modal("hide");
                // Refresh the table to reflect the changes
                refreshPersonnelTable();
            } else {
                // Display error message if server-side operation failed
                alert("Failed to add personnel. Please try again.");
            }
        },
        error: function (xhr, status, error) {
            // Handle AJAX errors
            // // console.error("AJAX error:", error);
            // Display error message to the user
            alert("AJAX error: " + error);
        }
    });
});

// Function to refresh the personnel table
function refreshPersonnelTable() {
    var searchText = $("#searchInp").val().trim();
    fetchAndGenerateTable(searchText, 'personnelTableBody');
}




// Event listener for edit button click
$(document).on('click', '.Personnel-edit-btn', function() {
    var Personnelid = $(this).data('id');
    var PersonneltfirstName = $(this).data('firstname');
    var PersonneltlastName = $(this).data('lastname');
    var Personneltemail = $(this).data('email');
    var PersonneldepartmentID = $(this).data('departmentid');

    // Make AJAX call to fetch department details
    $.ajax({
        url: "php/getDepartmentDetails.php",
        type: "GET",
        dataType: "json",
        success: function (response) {
            var DepartmentData = response.data;
            openEditPersonnelModal(Personnelid, PersonneltfirstName, PersonneltlastName, Personneltemail, PersonneldepartmentID, DepartmentData);
        },
        error: function (xhr, status, error) {
            // // console.error(error);
        }
    });
});

// Function to populate the edit personnel modal
function openEditPersonnelModal(personnelId, firstName, lastName, email, departmentId, departmentData) {
    $('#editPersonnelID').val(personnelId);
    $('#editPersonnelFirstName').val(firstName);
    $('#editPersonnelLastName').val(lastName);
    $('#editPersonnelEmailAddress').val(email);

    // Clear previous options
    $('#editPersonnelDepartment').empty();

    // Populate department options
    $.each(departmentData, function(index, department) {
        var option = $('<option>', {
            value: department.id,
            text: department.name
        });

        // Set selected attribute if it matches the personnel's department
        if (department.name === departmentId) {
            option.attr('selected', 'selected');
        }

        $('#editPersonnelDepartment').append(option);
    });

    $('#editPersonnelModal').modal('show');
}

// Function to handle the submission of the "Edit Personnel" form
$("#saveEditPersonnelForm").click(function () {
    var editPersonnelId = $('#editPersonnelID').val();
    var editPersonnelFirstName = $('#editPersonnelFirstName').val();
    var editPersonnelLastName = $('#editPersonnelLastName').val();
    var editPersonnelEmailAddress = $('#editPersonnelEmailAddress').val();
    var editPersonnelDepartment = $('#editPersonnelDepartment').val();

    // AJAX request to send data to the server for updating the personnel
    $.ajax({
        url: "php/EditPersonnel.php",
        type: "POST",
        dataType: "json",
        data: {
            id: editPersonnelId,
            firstName: editPersonnelFirstName,
            lastName: editPersonnelLastName,
            email: editPersonnelEmailAddress,
            departmentID: editPersonnelDepartment
        },
        success: function (response) {
            // // console.log(response);
            if (response.status.code === "200") {
                // Close the modal after successful editing of personnel
                $("#editPersonnelModal").modal("hide");
                // Optionally, refresh the personnel table to reflect the changes
                fetchAndGenerateTable($("#searchInp").val().trim(), 'personnelTableBody');
            } else {
                alert("Failed to update personnel. Please try again.");
            }
        },
        error: function (xhr, status, error) {
            // // console.error("AJAX error:", error);
            alert("AJAX error: " + error);
        }
    });
});

// Event listener for delete button click
$(document).on('click', '.Personnel-delete-btn', function() {
    // Get data attributes from the button
    var personnelId = $(this).data('id');
    var personnelName = $(this).data('name');
    
    // Set data attributes in the modal for further processing
    $('#deletePersonnelModal').data('personnelId', personnelId);
    $('#deletePersonnelModal').data('personnelName', personnelName); // Add personnelName attribute
    
    // Show the delete modal
    $('#deletePersonnelModal').modal('show');
});

// Event listener for confirm delete button click
$('#confirmDeletePersonnelBtn').on('click', function() {
    // Get personnel ID and name from the modal data attributes
    var personnelId = $('#deletePersonnelModal').data('personnelId');
    var personnelName = $('#deletePersonnelModal').data('personnelName');
    
    // Call the deletePersonnel function
    deletePersonnel(personnelId, personnelName); // Pass personnelName as an argument
});

// Event listener for cancel button click for delete personnel modal
$('#cancelDeletePersonnelBtn').on('click', function() {
    // Hide the delete confirmation modal
    $('#deletePersonnelModal').modal('hide');
});


// Function to handle deletion of personnel
function deletePersonnel(personnelId, personnelName) {
    // AJAX request to send data to the server for deleting the personnel
    $.ajax({
        url: "php/deletePersonnel.php", // Replace with the actual URL of your server-side script for deleting personnel
        type: "POST", // Use POST method to send data
        dataType: "json", // Expect JSON response from the server
        data: {
            id: personnelId // Send the personnel ID to the server for deletion
        },
        success: function (response) {
            // // console.log(response);
            // Check if the server successfully processed the request
            if (response.status.code === "200") {
                // Remove the deleted personnel row from the table
                $('#personnelTableBody').find('[data-id="' + personnelId + '"]').closest('tr').remove();
                
                // Hide the delete confirmation modal
                $('#deletePersonnelModal').modal('hide');
            } else {
                // Display error message if server-side operation failed
                alert("Failed to delete personnel. Please try again.");
            }
        },
        error: function (xhr, status, error) {
            // Handle AJAX errors
            // // console.error("AJAX error:", error);
            // Display error message to the user
            alert("AJAX error: " + error);
        }
    });
}


// ******************************************************************************Departments***************************************************************


// Function to generate department table
function generateDepartmentTable(data) {
    let tableHtml = '';
    let key = 1; // Initialize a variable to keep track of the incrementing value

    // Add table rows with department details
    data.forEach(department => {
        tableHtml += '<tr>';
        tableHtml += `<td>${key++}</td>`;
        tableHtml += `<td>${department.name}</td>`;
        tableHtml += `<td>${department.locationName}</td>`; // Display department location
        tableHtml += '<td>';
        // Edit button with data attributes for name and locationName
        tableHtml += `<button class="btn btn-primary btn-sm Department-edit-btn" data-departmentlocationname="${department.locationName}" data-id="${department.id}" data-name="${department.name}" data-locationName="${department.locationName}"><i class="fa-solid fa-pencil fa-fw"></i></button>`;
        // Add some space between the buttons
        tableHtml += '&nbsp;';
        // Delete button with data attributes for name and locationName
        tableHtml += `<button class="btn btn-danger btn-sm Department-delete-btn" data-id="${department.id}" data-name="${department.name}" data-locationName="${department.locationName}"><i class="fa-solid fa-trash fa-fw"></i></button>`;
        tableHtml += '</td>';
        tableHtml += '</tr>';
    });
    // Update the department table body with the generated HTML
    $('#departmentTableBody').html(tableHtml);
}

// Function to fetch and generate department table
function fetchAndGenerateDepartmentTable(searchText) {
    $.ajax({
        url: "php/getAllDepartments.php",
        type: "GET",
        dataType: "json",
        data: {
            txt: searchText // Pass search text to the server-side script
        },
        success: function (response) {
            // Handle the response data here
            // // console.log(response);
            // Generate table for departments
            generateDepartmentTable(response.data);
        },
        error: function (xhr, status, error) {
            // Handle errors here
            // // console.error(error);
        }
    });
}

// Initial table generation
fetchAndGenerateDepartmentTable(null);

// Function to populate the department location dropdown in the department modal
function populateDepartmentLocationDropdown() {
    $.ajax({
        url: "php/getLocationDetails.php",
        type: "GET",
        dataType: "json",
        success: function(response) {
            // Clear existing dropdown options
            $('#departmentLocationDropdown').empty();
            // Populate dropdown with fetched locations
            $.each(response.data, function(index, location) {
                $('#departmentLocationDropdown').append($('<option>', {
                    value: location.locationid,
                    text: location.locationname
                }));
            });
        },
        error: function(xhr, status, error) {
            // // console.error("Error fetching locations:", error);
            // Handle error if needed
        }
    });
}

// Event listener to detect when the department modal is shown
$('#addDepartmentModal').on('shown.bs.modal', function (e) {
    // Populate the department location dropdown when the modal is shown
    populateDepartmentLocationDropdown();
});
// Event listener for edit button click
$(document).on('click', '.Department-edit-btn', function() {
    var departmentId = $(this).data('id');
    var departmentName = $(this).data('name'); // Using data-name attribute
    var departmentlocationname = $(this).data('departmentlocationname'); // Using data-locationid attribute
    // alert(departmentlocationname);
    // Make AJAX call to fetch location details
    $.ajax({
        url: "php/getLocationDetails.php",
        type: "GET",
        dataType: "json",
    
        success: function (response) {
            // Handle the response data here
            var locationName = response.data;
            // Open edit department modal and pass department and location details
            openEditDepartmentModal(departmentId, departmentName, locationName,departmentlocationname);
        },
        error: function (xhr, status, error) {
            // Handle errors here
            // // console.error(error);
        }
    });
});

function openEditDepartmentModal(departmentId, departmentName, locationName,departmentlocationname) {
    $('#editDepartmentId').val(departmentId);
    $('#editDepartmentName').val(departmentName);
    // alert(departmentName);
    // Clear previous options
    $('#editDepartmentLocationDropdown').empty();

    // Check if locationName is an array
    if (Array.isArray(locationName)) {
        // Iterate over the array and append options
        $.each(locationName, function(index, location) {
            var option = $('<option>', {
                value: location.locationid,
                text: location.locationname
            });
            // Check if current location matches departmentName and set selected attribute
            if (location.locationname === departmentlocationname) {
                option.attr('selected', 'selected');
            }
            $('#editDepartmentLocationDropdown').append(option);
        });
    } else {
        // If locationName is not an array, assume it's a single location name
        $('#editDepartmentLocationDropdown').append($('<option>', {
            value: departmentName,
            text: departmentName,
            selected: 'selected'
        }));
    }

    $('#editDepartmentModal').modal('show');
}


// Function to handle the submission of the "Edit Department" form
$("#saveEditDepartmentBtn").click(function () {
    // Get the edited department ID, name, and location ID from the input fields
    var departmentId = $("#editDepartmentId").val().trim();
    var departmentName = $("#editDepartmentName").val().trim();
    var departmentLocationId = $("#editDepartmentLocationDropdown").val();

    // Validate if department name is not empty
    if (departmentName === "") {
        alert("Please enter a department name.");
        return;
    }

    // AJAX request to send data to the server for updating the department
    $.ajax({
        url: "php/editDepartment.php", // Replace with the actual URL of your server-side script for editing department
        type: "POST", // Use POST method to send data
        dataType: "json", // Expect JSON response from the server
        data: {
            id: departmentId, // Send the edited department ID to the server
            name: departmentName, // Send the edited department name to the server
            locationId: departmentLocationId // Send the edited department location ID to the server
        },
        success: function (response) {
            // // console.log(response);
            // Check if the server successfully processed the request
            if (response.status.code === "200") {
                // Close the modal after successful editing of department
                $("#editDepartmentModal").modal("hide");
                // Optionally, you can refresh the department table to reflect the changes
                fetchAndGenerateDepartmentTable(null); // Assuming you have a function to fetch and generate department table
            } else {
                // Display error message if server-side operation failed
                alert("Failed to update department. Please try again.");
            }
        },
        error: function (xhr, status, error) {
            // Handle AJAX errors
            // // console.error("AJAX error:", error);
            // Display error message to the user
            alert("AJAX error: " + error);
        }
    });
});

// Event listener for delete button click
$(document).on('click', '.Department-delete-btn', function() {
    var departmentId = $(this).data('id');
    var departmentName = $(this).data('name'); // Using data-name attribute
    var locationName = $(this).data('locationname'); // Using data-locationName attribute
    
    // Open the delete confirmation modal
    $('#deleteDepartmentModal').modal('show');
    
    // Set data attributes in the modal for further processing
    $('#deleteDepartmentModal').data('departmentId', departmentId);
    $('#deleteDepartmentModal').data('departmentName', departmentName);
    $('#deleteDepartmentModal').data('locationName', locationName);
});

// Event listener for confirm delete button click
$('#confirmDeleteDepartmentBtn').on('click', function() {
    // Get department details from the modal data attributes
    var departmentId = $('#deleteDepartmentModal').data('departmentId');
    var departmentName = $('#deleteDepartmentModal').data('departmentName');
    
    // Call the deleteDepartment function
    deleteDepartment(departmentId);
});

// Event listener for cancel button click
$('#cancelDeleteDepartmentBtn').on('click', function() {
    // Hide the delete confirmation modal
    $('#deleteDepartmentModal').modal('hide');
});

// Function to handle deletion of department
function deleteDepartment(departmentId) {
    // AJAX request to send data to the server for deleting the department
    $.ajax({
        url: "php/deleteDepartment.php", // Replace with the actual URL of your server-side script for deleting department
        type: "POST", // Use POST method to send data
        dataType: "json", // Expect JSON response from the server
        data: {
            id: departmentId // Send the department ID to the server for deletion
        },
        success: function (response) {
            // // console.log(response);
            // Check if the server successfully processed the request
            if (response.status.code === "200") {
                // Optionally, you can refresh the department table to reflect the changes
                fetchAndGenerateDepartmentTable(null); // Assuming you have a function to fetch and generate department table
                // Hide the delete confirmation modal
                $('#deleteDepartmentModal').modal('hide');
            } else {
                // Display error message if server-side operation failed
                alert("Failed to delete department. Please try again.");
            }
        },
        error: function (xhr, status, error) {
            // Handle AJAX errors
            // // console.error("AJAX error:", error);
            // Display error message to the user
            alert("AJAX error: " + error);
        }
    });
}

// Function to handle the submission of the "Add Department" form
$("#saveDepartmentBtn").click(function () {
    // Get the department name from the input field
    var departmentName = $("#departmentName").val().trim();
    var departmentLocationDropdown = $("#departmentLocationDropdown").val();
    
    // Validate if department name is not empty
    if (departmentName === "") {
        alert("Please enter a department name.");
        return;
    }

    // AJAX request to send data to the server
    $.ajax({
        url: "php/createDepartment.php", // Replace with the actual URL of your server-side script for creating departments
        type: "POST", // Use POST method to send data
        dataType: "json", // Expect JSON response from the server
        data: {
            name: departmentName, // Send the department name to the server
            locationID: departmentLocationDropdown // Send the department name to the server
        },
        success: function (response) {
            // // console.log(response);
            // Check if the server successfully processed the request
            if (response.status.code === "200") {
                // Close the modal after successful addition of department
                $("#addDepartmentModal").modal("hide");
                // Optionally, you can refresh the department table to reflect the changes
                fetchAndGenerateDepartmentTable(null); // Assuming you have a function to fetch and generate department table
            } else {
                // Display error message if server-side operation failed
                alert("Failed to add department. Please try again.");
            }
        },
        error: function (xhr, status, error) {
            // Handle AJAX errors
            // // console.error("AJAX error:", error);
            // Display error message to the user
            alert("AJAX error: " + error);
        }
    });
});

// ******************************************************************************Departments***************************************************************


// ******************************************************************************Locations***************************************************************


// Function to generate location table
function generateLocationTable(data) {
    let tableHtml = '';
    let key = 1; // Initialize a variable to keep track of the incrementing value
    data.forEach(location => {
        tableHtml += '<tr>';
        tableHtml += `<td>${key++}</td>`;
        tableHtml += `<td>${location.locationname}</td>`;
        tableHtml += '<td>';
        tableHtml += `<button class="btn btn-primary btn-sm edit-btn Location-edit-btn" data-id="${location.locationid}" data-name="${location.locationname}"><i class="fa-solid fa-pencil fa-fw"></i></button>`;
        tableHtml += '&nbsp;';
        tableHtml += `<button class="btn btn-danger btn-sm delete-btn Location-delete-btn" data-id="${location.locationid}"><i class="fa-solid fa-trash fa-fw"></i></button>`;
        tableHtml += '</td>';
        tableHtml += '</tr>';
    });
    $('#locationTableBody').html(tableHtml);
}


    // Function to fetch and generate location table
    function fetchAndGenerateLocationTable(searchText) {
        $.ajax({
            url: "php/getLocationDetails.php",
            type: "GET",
            dataType: "json",
            data: {
                txt: searchText // Pass search text to the server-side script
            },
            success: function (response) {
                // Handle the response data here
                // // console.log(response);
                // Generate table for locations
                generateLocationTable(response.data);
            },
            error: function (xhr, status, error) {
                // Handle errors here
                // // console.error(error);
            }
        });
    }

    // Initial table generation for locations
    fetchAndGenerateLocationTable(null);

   


// Function to open edit modal
function openEditModal(locationId, locationName) {
    $('#editLocationId').val(locationId);
    $('#editLocationName').val(locationName);
    $('#editLocationModal').modal('show');
}

// Function to open edit modal
$(document).on('click', '.Location-edit-btn', function() {
    var locationId = $(this).data('id');
    var locationName = $(this).data('name');
    openEditModal(locationId, locationName);
});


// Function to handle the submission of the "Edit Location" form
$("#saveChangesBtn").click(function () {
    // Get the edited location ID and name from the input fields
    var locationId = $("#editLocationId").val().trim();
    var locationName = $("#editLocationName").val().trim();
    
    // Validate if location name is not empty
    if (locationName === "") {
        alert("Please enter a location name.");
        return;
    }

    // AJAX request to send data to the server for updating the location
    $.ajax({
        url: "php/editLocation.php", // Replace with the actual URL of your server-side script for updating location
        type: "POST", // Use POST method to send data
        dataType: "json", // Expect JSON response from the server
        data: {
            id: locationId, // Send the edited location ID to the server
            name: locationName // Send the edited location name to the server
        },
        success: function (response) {
            // // console.log(response);
            // Check if the server successfully processed the request
            if (response.status.code === "200") {
                // Close the modal after successful editing of location
                $("#editLocationModal").modal("hide");

                // Optionally, you can refresh the location table to reflect the changes
                fetchAndGenerateLocationTable(null); // Assuming you have a function to fetch and generate location table
            } else {
                // Display error message if server-side operation failed
                alert("Failed to update location. Please try again.");
            }
        },
        error: function (xhr, status, error) {
            // Handle AJAX errors
            // // console.error("AJAX error:", error);
            // Display error message to the user
            alert("AJAX error: " + error);
        }
    });
});

// Event listener for delete button click for locations
$(document).on('click', '.Location-delete-btn', function() {
    var locationId = $(this).data('id');
    var locationName = $(this).data('name'); // Using data-name attribute
    
    // Open the delete confirmation modal
    $('#deleteLocationModal').modal('show');
    
    // Set data attributes in the modal for further processing
    $('#deleteLocationModal').data('locationId', locationId);
    $('#deleteLocationModal').data('locationName', locationName);
});

// Event listener for confirm delete button click for locations
$('#confirmDeleteLocationBtn').on('click', function() {
    // Get location details from the modal data attributes
    var locationId = $('#deleteLocationModal').data('locationId');
    
    // Call the deleteLocation function
    deleteLocation(locationId);
});

// Event listener for cancel button click
$('#cancelDeleteLocationBtn').on('click', function() {
    // Hide the delete confirmation modal
    $('#deleteLocationModal').modal('hide');
});


// Function to handle deletion of location
function deleteLocation(locationId) {
    // AJAX request to send data to the server for deleting the location
    $.ajax({
        url: "php/deleteLocation.php", // Replace with the actual URL of your server-side script for deleting location
        type: "POST", // Use POST method to send data
        dataType: "json", // Expect JSON response from the server
        data: {
            id: locationId // Send the location ID to the server for deletion
        },
        success: function (response) {
            // // console.log(response);
            // Check if the server successfully processed the request
            if (response.status.code === "200") {
                // Optionally, you can refresh the location table to reflect the changes
                fetchAndGenerateLocationTable(null); // Assuming you have a function to fetch and generate location table
                // Hide the delete confirmation modal
                $('#deleteLocationModal').modal('hide');
            } else {
                // Display error message if server-side operation failed
                alert("Failed to delete location. Please try again.");
            }
        },
        error: function (xhr, status, error) {
            // Handle AJAX errors
            // // console.error("AJAX error:", error);
            // Display error message to the user
            alert("AJAX error: " + error);
        }
    });
}



// Function to handle the submission of the "Add Location" form
$("#saveLocationBtn").click(function () {
    // Get the location name from the input field
    var locationName = $("#locationName").val().trim();
    
    // Validate if location name is not empty
    if (locationName === "") {
        alert("Please enter a location name.");
        return;
    }

    // AJAX request to send data to the server
    $.ajax({
        url: "php/createLocation.php", // Replace with the actual URL of your server-side script
        type: "POST", // Use POST method to send data
        dataType: "json", // Expect JSON response from the server
        data: {
            name: locationName // Send the location name to the server
        },
        success: function (response) {
            // // console.log(response);
            // Check if the server successfully processed the request
            if (response.status.code === "200") {
                // Close the modal after successful addition of location
                $("#addLocationModal").modal("hide");
                // Optionally, you can refresh the location table to reflect the changes
                fetchAndGenerateLocationTable(null); // Assuming you have a function to fetch and generate location table
            } else {
                // Display error message if server-side operation failed
                alert("Failed to add location. Please try again.");
            }
        },
        error: function (xhr, status, error) {
            // Handle AJAX errors
            // // console.error("AJAX error:", error);
            // Display error message to the user
            alert("AJAX error: " + error);
        }
    });
});

// ******************************************************************************Locations***************************************************************


    // Add button functionality
    $("#addBtn").click(function () {
        var modalpopupvalue = $("#searchType").val();
    
        if (modalpopupvalue == 'personnel') { 
            $("#addpersonnelModal").modal("show");
        }
        else if (modalpopupvalue == 'department') { 
            $("#addDepartmentModal").modal("show");
        }
        else if (modalpopupvalue == 'location') { 
            $("#addLocationModal").modal("show");
        }
    });
    
    







 // Refresh button functionality
 $("#refreshBtn").click(function () {
    if ($("#personnelBtn").hasClass("active")) {
        // Refresh personnel table
        fetchAndGenerateTable(null, 'personnelTableBody');
    } else if ($("#departmentsBtn").hasClass("active")) {
        // Refresh department table
        fetchAndGenerateDepartmentTable(null);
    } else {
        // Refresh location table
        fetchAndGenerateLocationTable(null);
    }
});






    // Personnel button click
    $("#personnelBtn").click(function () {
        // Call function to refresh personnel table
        fetchAndGenerateTable(null, 'personnelTableBody');
        $("#searchInp").val(''); // Clear search input
        $("#searchType").val(''); 

        $("#searchType").val('personnel'); 

    });

    // Departments button click
    $("#departmentsBtn").click(function () {
        // Call function to refresh department table
        fetchAndGenerateDepartmentTable(null);
        $("#searchInp").val(''); // Clear search input
        $("#searchType").val(''); 

        $("#searchType").val('department'); 
    });

    // Locations button click
    $("#locationsBtn").click(function () {
        // Call function to refresh location table
        fetchAndGenerateLocationTable(null);
        $("#searchInp").val(''); // Clear search input
        $("#searchType").val(''); 

        $("#searchType").val('location'); 
    });

    // Edit personnel modal event
    $("#editPersonnelModal").on("show.bs.modal", function (e) {
        $.ajax({
            url: "https://coding.itcareerswitch.co.uk/companydirectory/libs/php/getPersonnelByID.php",
            type: "POST",
            dataType: "json",
            data: {
                id: $(e.relatedTarget).attr("data-id")
            },
            success: function (result) {
                var resultCode = result.status.code;

                if (resultCode == 200) {
                    $("#editPersonnelEmployeeID").val(result.data.personnel[0].id);
                    $("#editPersonnelFirstName").val(result.data.personnel[0].firstName);
                    $("#editPersonnelLastName").val(result.data.personnel[0].lastName);
                    $("#editPersonnelJobTitle").val(result.data.personnel[0].jobTitle);
                    $("#editPersonnelEmailAddress").val(result.data.personnel[0].email);

                    $("#editPersonnelDepartment").html("");

                    $.each(result.data.department, function () {
                        $("#editPersonnelDepartment").append(
                            $("<option>", {
                                value: this.id,
                                text: this.name
                            })
                        );
                    });

                    $("#editPersonnelDepartment").val(result.data.personnel[0].departmentID);
                } else {
                    $("#editPersonnelModal .modal-title").replaceWith("Error retrieving data");
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                $("#editPersonnelModal .modal-title").replaceWith("Error retrieving data");
            }
        });
    });

    // Edit personnel form submission
    $("#editPersonnelForm").on("submit", function (e) {
        e.preventDefault(); // Prevent default form submission

        // Serialize form data
        var formData = $(this).serialize();

        // Send AJAX request to update personnel information
        $.ajax({
            url: "php/updatePersonnel.php", // Update the URL with your server-side script for updating personnel
            type: "POST",
            data: formData,
            dataType: "json",
            success: function (response) {
                // Handle successful response
                if (response.success) {
                    // Personnel information updated successfully
                    // Close the modal
                    $("#editPersonnelModal").modal("hide");

                    // Display success message to the user
                    $("#editPersonnelForm").after('<div class="alert alert-success mt-3" role="alert">Personnel information updated successfully.</div>');

                    // Optionally, you can refresh the personnel table to reflect the changes
                    fetchAndGenerateTable(null, 'personnelTableBody');
                } else {
                    // Handle errors or display a message to the user
                    // // console.error("Error updating personnel information:", response.message);
                    // Display error message to the user
                    $("#editPersonnelForm").after('<div class="alert alert-danger mt-3" role="alert">Error updating personnel information: ' + response.message + '</div>');
                }
            },
            error: function (xhr, status, error) {
                // Handle AJAX errors
                // // console.error("AJAX error:", error);
                // Display error message to the user
                $("#editPersonnelForm").after('<div class="alert alert-danger mt-3" role="alert">AJAX error: ' + error + '</div>');
            }
        });
    });

    // // Function to refresh the personnel table
    // function refreshPersonnelTable() {
    //     fetchAndGenerateTable(null, 'personnelTableBody');
    // }

    // // Function to refresh the department table
    // function refreshDepartmentTable() {
    //     fetchAndGenerateDepartmentTable(null);
    // }

    // // Function to refresh the location table
    // function refreshLocationTable() {
    //     fetchAndGenerateLocationTable(null);
    // }

   //Filter
        $(document).on('click', '#filterBtn', function() {
            var filterData = $('#searchType').val(); 
            $.ajax({
                url: 'php/filterAllData.php',  // Replace with your actual deletion script
                type: 'POST',
                data: { filterData: filterData },
                success: function(response) {
                    // // console.log(response);
                    // Update the table with the search results
                    switch (filterData) {
                        case 'personnel':
                            generatePersonnelSearchTable(response.data);
                            break;
                        case 'department':
                            generateDepartmentSearchTable(response.data);
                            break;
                        case 'location':
                            generateLocationSearchTable(response.data);
                            break;
                        default:
                            // // console.error('Invalid search type:', searchType);
                    }
                },
                error: function(xhr, status, error) {
                    // Handle error
                    // // console.error("AJAX error:", error);
                    alert("Failed to delete personnel. Please try again.");
                }
            });
        });
        
});


// Function to handle close button click event
function handleCloseButtonClick() {
    $('#editDepartmentModal, #editLocationModal, #addDepartmentModal, #addLocationModal').modal('hide');
}

// Attach event listener to close buttons
$(document).on('click', '.modal .close', handleCloseButtonClick);
$(document).on('click', '.modal .btn-secondary', handleCloseButtonClick);
